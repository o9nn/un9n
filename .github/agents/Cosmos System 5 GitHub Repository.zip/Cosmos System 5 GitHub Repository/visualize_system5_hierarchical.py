#!/usr/bin/env python3
"""
System 5 Hierarchical Deterministic State Transition Visualization
Generates visual representations of the deterministic state sequences
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from matplotlib.colors import ListedColormap

def plot_deterministic_schedule():
    """Plot the deterministic state sequences as a timeline"""
    
    SIMULATION_STEPS = 60
    
    # --- Simulation Logic Re-run (Must match C++ logic) ---
    
    S_NUM_STATES = 4
    F_NUM_STATES = 4
    
    # Synchronous Sets
    s_history = [[], [], [], []]
    
    # Tensor Bundles (4 bundles x 3 threads = 12 threads)
    f_history = [[] for _ in range(12)]
    f_current_states = [0] * 12
    
    def get_thread_index(bundle_idx, thread_idx):
        return bundle_idx * 3 + thread_idx

    for t in range(SIMULATION_STEPS + 1):
        # 1. Synchronous Transitions (S1, S2, S3, S4)
        s_current_states = [t % S_NUM_STATES] * 4
        s4_state = s_current_states[3] # S4 is the global influence
        
        for i in range(4):
            s_history[i].append(s_current_states[i])
        
        # 2. Tensor Bundle Transitions (Inter-Bundle Concurrency)
        f_next_states = list(f_current_states)
        
        for i in range(4): # Bundle index (0 to 3)
            
            # Check if bundle is active
            if t % 5 == i:
                
                # Intra-Bundle Concurrency (Level 2)
                for j in range(3): # Thread index (0 to 2)
                    
                    thread_idx = get_thread_index(i, j)
                    
                    # Sum of states of the other two threads in the bundle
                    sum_of_others = 0
                    for k in range(3):
                        if j != k:
                            sum_of_others += f_current_states[get_thread_index(i, k)]
                    
                    # Transition Function: S_i,j(t+1) = (S_i,j(t) + sum(S_i,k(t)) + S_4(t)) mod 4
                    next_state = (f_current_states[thread_idx] + sum_of_others + s4_state) % F_NUM_STATES
                    f_next_states[thread_idx] = next_state
            
            # Update history for all threads (active or inactive)
            for j in range(3):
                f_history[get_thread_index(i, j)].append(f_current_states[get_thread_index(i, j)])
                
        f_current_states = f_next_states
        
    # --- Visualization ---
    
    all_sequences = s_history + f_history
    set_names = ["S1", "S2", "S3", "S4", 
                 "T1-F1", "T1-F2", "T1-F3", 
                 "T2-F1", "T2-F2", "T2-F3", 
                 "T3-F1", "T3-F2", "T3-F3", 
                 "T4-F1", "T4-F2", "T4-F3"]
    
    # Map all unique states to colors
    all_states_str = [str(state) for seq in all_sequences for state in seq]
    unique_states = sorted(list(set(all_states_str)))
    num_states = len(unique_states)
    
    # Create a colormap
    cmap = plt.cm.get_cmap('tab20', num_states)
    state_to_color = {state: cmap(i) for i, state in enumerate(unique_states)}
    
    fig, ax = plt.subplots(figsize=(20, 12))
    
    # Plot each set's sequence
    for i, (set_name, seq) in enumerate(zip(set_names, all_sequences)):
        y_pos = len(set_names) - i - 1
        
        for t in range(SIMULATION_STEPS + 1):
            state = str(seq[t]) # Convert to string for lookup and display
            color = state_to_color[state]
            
            rect = mpatches.Rectangle((t - 0.5, y_pos - 0.4), 1.0, 0.8,
                                      facecolor=color, edgecolor='black', linewidth=0.5)
            ax.add_patch(rect)
            
            # Add state label
            ax.text(t, y_pos, state, ha='center', va='center', fontsize=7, color='black', fontweight='bold')
    
    # Formatting
    ax.set_xlim(-1, SIMULATION_STEPS + 1)
    ax.set_ylim(-1, len(set_names))
    ax.set_yticks(range(len(set_names)))
    ax.set_yticklabels(set_names[::-1], fontsize=10, fontweight='bold')
    ax.set_xticks(range(SIMULATION_STEPS + 1))
    ax.set_xlabel('Time Step (t)', fontsize=14, fontweight='bold')
    ax.set_title('System 5 Hierarchical State Transition Timeline (60 Steps)', 
                 fontsize=16, fontweight='bold', pad=20)
    ax.grid(True, axis='x', alpha=0.3)
    
    # Add cycle markers
    for t in range(1, SIMULATION_STEPS + 1):
        if t % 4 == 0: # Synchronous cycle
            ax.axvline(x=t - 0.5, color='blue', linestyle=':', linewidth=1, alpha=0.5)
        if t % 5 == 0: # Bundle stagger cycle
            ax.axvline(x=t - 0.5, color='red', linestyle='--', linewidth=1, alpha=0.7)
    
    # Create a legend for the states
    legend_patches = [mpatches.Patch(color=state_to_color[state], label=str(state)) for state in unique_states]
    ax.legend(handles=legend_patches, title="States", bbox_to_anchor=(1.05, 1), loc='upper left', ncol=1)
    
    plt.tight_layout(rect=[0, 0, 0.85, 1]) # Adjust layout to make room for legend
    plt.savefig('/home/ubuntu/system5_hierarchical_timeline.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: system5_hierarchical_timeline.png")
    plt.close()

def main():
    print("\n" + "="*80)
    print("System 5 Hierarchical Deterministic State Transition Visualization")
    print("="*80 + "\n")
    
    print("Generating visualizations...\n")
    
    plot_deterministic_schedule()
    
    print("\n" + "="*80)
    print("All visualizations generated successfully!")
    print("="*80 + "\n")

if __name__ == "__main__":
    main()
