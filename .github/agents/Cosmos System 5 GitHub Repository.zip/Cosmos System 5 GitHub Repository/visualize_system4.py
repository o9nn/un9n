#!/usr/bin/env python3
"""
System 4 State Transition Visualization
Generates visual representations of the state transition patterns
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from matplotlib.colors import ListedColormap

def plot_transition_schedule():
    """Plot the transition schedule showing when each set is active"""
    fig, ax = plt.subplots(figsize=(16, 8))
    
    max_time = 24
    sets = ['U1', 'U2', 'P1', 'P2', 'P3']
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7']
    
    # Define when each set transitions
    def should_universal_1_step(t):
        return (t % 4 == 0 or t % 4 == 1)
    
    def should_universal_2_step(t):
        return (t % 4 == 2 or t % 4 == 3)
    
    def should_particular_1_step(t):
        return (t % 4 == 0)
    
    def should_particular_2_step(t):
        return (t % 4 == 1)
    
    def should_particular_3_step(t):
        return (t % 4 == 2)
    
    schedules = [
        should_universal_1_step,
        should_universal_2_step,
        should_particular_1_step,
        should_particular_2_step,
        should_particular_3_step
    ]
    
    # Plot each set's schedule
    for i, (set_name, schedule_func, color) in enumerate(zip(sets, schedules, colors)):
        y_pos = len(sets) - i - 1
        
        for t in range(max_time + 1):
            if schedule_func(t):
                rect = mpatches.Rectangle((t - 0.4, y_pos - 0.4), 0.8, 0.8,
                                          facecolor=color, edgecolor='black', linewidth=1.5)
                ax.add_patch(rect)
            else:
                rect = mpatches.Rectangle((t - 0.4, y_pos - 0.4), 0.8, 0.8,
                                          facecolor='white', edgecolor='gray', 
                                          linewidth=0.5, linestyle='--')
                ax.add_patch(rect)
    
    # Formatting
    ax.set_xlim(-1, max_time + 1)
    ax.set_ylim(-1, len(sets))
    ax.set_yticks(range(len(sets)))
    ax.set_yticklabels(sets[::-1], fontsize=12, fontweight='bold')
    ax.set_xticks(range(max_time + 1))
    ax.set_xlabel('Time Step', fontsize=14, fontweight='bold')
    ax.set_title('System 4 Transition Schedule\n2 Synchronous Universal Sets (Alternate Double Steps) + 3 Concurrent Particular Sets (4 Steps Apart)', 
                 fontsize=16, fontweight='bold', pad=20)
    ax.grid(True, axis='x', alpha=0.3)
    
    # Add legend
    legend_elements = [
        mpatches.Patch(facecolor=colors[0], edgecolor='black', label='U1: Universal Set 1'),
        mpatches.Patch(facecolor=colors[1], edgecolor='black', label='U2: Universal Set 2'),
        mpatches.Patch(facecolor=colors[2], edgecolor='black', label='P1: Particular Set 1'),
        mpatches.Patch(facecolor=colors[3], edgecolor='black', label='P2: Particular Set 2'),
        mpatches.Patch(facecolor=colors[4], edgecolor='black', label='P3: Particular Set 3'),
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/system4_transition_schedule.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: system4_transition_schedule.png")
    plt.close()

def plot_transition_matrices():
    """Plot the transition probability matrices as heatmaps"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # Universal Set Transition Matrix (5x5)
    universal_matrix = np.array([
        [0.10, 0.40, 0.30, 0.10, 0.10],
        [0.20, 0.20, 0.30, 0.20, 0.10],
        [0.10, 0.20, 0.20, 0.30, 0.20],
        [0.10, 0.10, 0.20, 0.30, 0.30],
        [0.20, 0.10, 0.10, 0.20, 0.40]
    ])
    
    # Particular Set Transition Matrix (4x4)
    particular_matrix = np.array([
        [0.30, 0.40, 0.20, 0.10],
        [0.20, 0.30, 0.30, 0.20],
        [0.10, 0.20, 0.40, 0.30],
        [0.20, 0.20, 0.20, 0.40]
    ])
    
    # Plot Universal Set Matrix
    im1 = ax1.imshow(universal_matrix, cmap='YlOrRd', aspect='auto', vmin=0, vmax=1)
    ax1.set_xticks(range(5))
    ax1.set_yticks(range(5))
    ax1.set_xticklabels([f'S{i}' for i in range(5)], fontsize=11)
    ax1.set_yticklabels([f'S{i}' for i in range(5)], fontsize=11)
    ax1.set_xlabel('To State', fontsize=12, fontweight='bold')
    ax1.set_ylabel('From State', fontsize=12, fontweight='bold')
    ax1.set_title('Universal Set Transition Matrix\n(U1 & U2)', fontsize=13, fontweight='bold')
    
    # Add text annotations
    for i in range(5):
        for j in range(5):
            text = ax1.text(j, i, f'{universal_matrix[i, j]:.2f}',
                          ha="center", va="center", color="black" if universal_matrix[i, j] < 0.5 else "white",
                          fontsize=10, fontweight='bold')
    
    plt.colorbar(im1, ax=ax1, label='Transition Probability')
    
    # Plot Particular Set Matrix
    im2 = ax2.imshow(particular_matrix, cmap='YlGnBu', aspect='auto', vmin=0, vmax=1)
    ax2.set_xticks(range(4))
    ax2.set_yticks(range(4))
    ax2.set_xticklabels([f'S{i}' for i in range(4)], fontsize=11)
    ax2.set_yticklabels([f'S{i}' for i in range(4)], fontsize=11)
    ax2.set_xlabel('To State', fontsize=12, fontweight='bold')
    ax2.set_ylabel('From State', fontsize=12, fontweight='bold')
    ax2.set_title('Particular Set Transition Matrix\n(P1, P2 & P3)', fontsize=13, fontweight='bold')
    
    # Add text annotations
    for i in range(4):
        for j in range(4):
            text = ax2.text(j, i, f'{particular_matrix[i, j]:.2f}',
                          ha="center", va="center", color="black" if particular_matrix[i, j] < 0.5 else "white",
                          fontsize=10, fontweight='bold')
    
    plt.colorbar(im2, ax=ax2, label='Transition Probability')
    
    plt.suptitle('System 4 State Transition Probability Matrices', fontsize=16, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig('/home/ubuntu/system4_transition_matrices.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: system4_transition_matrices.png")
    plt.close()

def plot_synchronization_pattern():
    """Plot the synchronization pattern showing universal vs particular sets"""
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 8))
    
    max_time = 24
    
    # Universal Sets - Synchronous Alternate Double Steps
    ax1.set_title('Universal Sets: Synchronous Alternate Double Steps', fontsize=14, fontweight='bold')
    
    for t in range(max_time + 1):
        cycle_pos = t % 4
        if cycle_pos == 0 or cycle_pos == 1:
            # U1 active
            rect = mpatches.Rectangle((t - 0.4, 0.6), 0.8, 0.8,
                                      facecolor='#FF6B6B', edgecolor='black', linewidth=2)
            ax1.add_patch(rect)
        else:
            # U2 active
            rect = mpatches.Rectangle((t - 0.4, -0.4), 0.8, 0.8,
                                      facecolor='#4ECDC4', edgecolor='black', linewidth=2)
            ax1.add_patch(rect)
    
    ax1.set_xlim(-1, max_time + 1)
    ax1.set_ylim(-1, 2)
    ax1.set_yticks([0, 1])
    ax1.set_yticklabels(['U2', 'U1'], fontsize=12, fontweight='bold')
    ax1.set_xticks(range(max_time + 1))
    ax1.set_xlabel('Time Step', fontsize=12)
    ax1.grid(True, axis='x', alpha=0.3)
    ax1.axhline(y=0.5, color='red', linestyle='--', linewidth=2, alpha=0.5, label='Synchronization Boundary')
    ax1.legend(loc='upper right')
    
    # Particular Sets - Concurrent 4 Steps Apart
    ax2.set_title('Particular Sets: Concurrent (4 Steps Apart)', fontsize=14, fontweight='bold')
    
    colors_p = ['#45B7D1', '#96CEB4', '#FFEAA7']
    labels_p = ['P1', 'P2', 'P3']
    
    for t in range(max_time + 1):
        if t % 4 == 0:
            rect = mpatches.Rectangle((t - 0.4, 1.6), 0.8, 0.8,
                                      facecolor=colors_p[0], edgecolor='black', linewidth=2)
            ax2.add_patch(rect)
        if t % 4 == 1:
            rect = mpatches.Rectangle((t - 0.4, 0.6), 0.8, 0.8,
                                      facecolor=colors_p[1], edgecolor='black', linewidth=2)
            ax2.add_patch(rect)
        if t % 4 == 2:
            rect = mpatches.Rectangle((t - 0.4, -0.4), 0.8, 0.8,
                                      facecolor=colors_p[2], edgecolor='black', linewidth=2)
            ax2.add_patch(rect)
    
    ax2.set_xlim(-1, max_time + 1)
    ax2.set_ylim(-1, 3)
    ax2.set_yticks([0, 1, 2])
    ax2.set_yticklabels(['P3', 'P2', 'P1'], fontsize=12, fontweight='bold')
    ax2.set_xticks(range(max_time + 1))
    ax2.set_xlabel('Time Step', fontsize=12)
    ax2.grid(True, axis='x', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/system4_synchronization_pattern.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: system4_synchronization_pattern.png")
    plt.close()

def main():
    print("\n" + "="*80)
    print("System 4 State Transition Visualization")
    print("="*80 + "\n")
    
    print("Generating visualizations...\n")
    
    plot_transition_schedule()
    plot_transition_matrices()
    plot_synchronization_pattern()
    
    print("\n" + "="*80)
    print("All visualizations generated successfully!")
    print("="*80 + "\n")

if __name__ == "__main__":
    main()
