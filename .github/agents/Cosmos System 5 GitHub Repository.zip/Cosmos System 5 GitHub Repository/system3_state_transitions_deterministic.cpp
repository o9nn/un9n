/**
 * @brief System 3 Deterministic State Transition Implementation
 * 
 * This implementation models System 3 with deterministic, fixed-sequence transitions
 * based on the user-provided 4-step cycle and state labels.
 * 
 * - 1 Universal Set (U1) with a 4-step cycle.
 * - 2 Particular Sets (P1, P2) with a 4-step cycle.
 * 
 * Uses CogTaskFlow for parallel state transition processing.
 */

#include <taskflow/taskflow.hpp>
#include <taskflow/cognitive/cognitive.hpp>
#include <iostream>
#include <vector>
#include <array>
#include <string>
#include <iomanip>
#include <sstream>
#include <algorithm>

// ============================================================================
// State Definitions and Sequences
// ============================================================================

const int CYCLE_LENGTH = 4;

// Universal Set Sequence (4 steps)
const std::array<std::string, CYCLE_LENGTH> U1_SEQUENCE = {
    "4E", "3R", "4E", "3R"
};

// Particular Set Sequences (4 steps)
const std::array<std::string, CYCLE_LENGTH> P1_SEQUENCE = {
    "2E", "1E", "2E", "1R"
};

const std::array<std::string, CYCLE_LENGTH> P2_SEQUENCE = {
    "1R", "2E", "1E", "2E"
};

// ============================================================================
// State Set Classes
// ============================================================================

class DeterministicSet {
public:
    std::string name;
    std::string current_state;
    std::vector<std::string> state_history;
    const std::array<std::string, CYCLE_LENGTH>& sequence;
    
    DeterministicSet(const std::string& n, const std::array<std::string, CYCLE_LENGTH>& seq) 
        : name(n), sequence(seq) {
        current_state = sequence[0];
        state_history.push_back(current_state);
    }
    
    void transition(int time_step) {
        // The transition is purely deterministic based on the time step within the cycle
        int next_index = time_step % CYCLE_LENGTH;
        current_state = sequence[next_index];
        state_history.push_back(current_state);
    }
};

// ============================================================================
// System 3 State Machine
// ============================================================================

class System3StateMachine {
public:
    DeterministicSet u1{"U1", U1_SEQUENCE};
    DeterministicSet p1{"P1", P1_SEQUENCE};
    DeterministicSet p2{"P2", P2_SEQUENCE};
    
    int current_time;
    
    System3StateMachine() : current_time(0) {}
    
    void step(tf::Taskflow& taskflow) {
        // All sets transition at every step, their state is determined by the sequence index
        
        // Universal Set (U1)
        auto u1_task = taskflow.emplace([this]() {
            u1.transition(current_time);
        }).name("U1_transition");
        
        // Particular Sets (P1, P2)
        auto p1_task = taskflow.emplace([this]() {
            p1.transition(current_time);
        }).name("P1_transition");
        
        auto p2_task = taskflow.emplace([this]() {
            p2.transition(current_time);
        }).name("P2_transition");
        
        current_time++;
    }
    
    void print_current_state() const {
        std::cout << "t=" << std::setw(3) << current_time << ": "
                  << "U1=" << std::setw(3) << u1.current_state << " "
                  << "P1=" << std::setw(3) << p1.current_state << " "
                  << "P2=" << std::setw(3) << p2.current_state << "\n";
    }
    
    void print_state_history() const {
        std::cout << "\n" << std::string(80, '=') << "\n";
        std::cout << "State History (Cycle Length: " << CYCLE_LENGTH << ")\n";
        std::cout << std::string(80, '=') << "\n\n";
        
        int max_len = u1.state_history.size();
        
        std::cout << "Time  U1   P1   P2\n";
        std::cout << std::string(20, '-') << "\n";
        
        for (size_t t = 0; t < max_len; ++t) {
            std::cout << std::setw(4) << t << "  ";
            
            std::cout << std::setw(3) << u1.state_history[t] << "  ";
            std::cout << std::setw(3) << p1.state_history[t] << "  ";
            std::cout << std::setw(3) << p2.state_history[t];
            
            std::cout << "\n";
        }
    }
};

// ============================================================================
// Main Simulation
// ============================================================================

int main() {
    std::cout << "\n" << std::string(80, '=') << "\n";
    std::cout << "System 3 Deterministic State Transition Simulation\n";
    std::cout << "Using CogTaskFlow for Parallel Processing\n";
    std::cout << std::string(80, '=') << "\n";
    
    // Create System 3 state machine
    System3StateMachine system3;
    
    // Print the sequences for verification
    std::cout << "U1 Sequence: ";
    for(const auto& s : U1_SEQUENCE) std::cout << s << " ";
    std::cout << "\n";
    
    std::cout << "P1 Sequence: ";
    for(const auto& s : P1_SEQUENCE) std::cout << s << " ";
    std::cout << "\n";
    
    std::cout << "P2 Sequence: ";
    for(const auto& s : P2_SEQUENCE) std::cout << s << " ";
    std::cout << "\n\n";
    
    // Create taskflow executor
    tf::Executor executor;
    
    const int SIMULATION_STEPS = CYCLE_LENGTH * 3; // Run for three full cycles
    std::cout << "Running simulation for " << SIMULATION_STEPS << " time steps...\n\n";
    
    // Run simulation
    for (int t = 0; t < SIMULATION_STEPS; ++t) {
        tf::Taskflow taskflow;
        system3.step(taskflow);
        executor.run(taskflow).wait();
        system3.print_current_state();
    }
    
    // Print final state history
    system3.print_state_history();
    
    std::cout << std::string(80, '=') << "\n";
    std::cout << "Simulation Complete\n";
    std::cout << std::string(80, '=') << "\n\n";
    
    return 0;
}
