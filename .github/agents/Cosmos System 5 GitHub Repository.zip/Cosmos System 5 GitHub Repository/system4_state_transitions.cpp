/**
 * @brief System 4 State Transition Matrix Implementation
 * 
 * This implementation models System 4 with:
 * - 2 synchronous universal sets with alternate double steps
 * - 3 concurrent particular sets 4 steps apart
 * 
 * Uses CogTaskFlow for parallel state transition processing
 */

#include <taskflow/taskflow.hpp>
#include <taskflow/cognitive/cognitive.hpp>
#include <iostream>
#include <vector>
#include <array>
#include <random>
#include <iomanip>
#include <sstream>

// ============================================================================
// State Definitions
// ============================================================================

enum class UniversalState { S0, S1, S2, S3, S4 };
enum class ParticularState { S0, S1, S2, S3 };

const int NUM_UNIVERSAL_STATES = 5;
const int NUM_PARTICULAR_STATES = 4;

// ============================================================================
// Transition Matrix Definitions
// ============================================================================

class TransitionMatrix {
public:
    std::vector<std::vector<float>> matrix;
    int size;
    
    TransitionMatrix(int n) : size(n), matrix(n, std::vector<float>(n, 0.0f)) {}
    
    void set(int from, int to, float prob) {
        matrix[from][to] = prob;
    }
    
    float get(int from, int to) const {
        return matrix[from][to];
    }
    
    // Normalize rows to ensure probabilities sum to 1
    void normalize() {
        for (int i = 0; i < size; ++i) {
            float sum = 0.0f;
            for (int j = 0; j < size; ++j) {
                sum += matrix[i][j];
            }
            if (sum > 0.0f) {
                for (int j = 0; j < size; ++j) {
                    matrix[i][j] /= sum;
                }
            }
        }
    }
    
    void print(const std::string& name) const {
        std::cout << "\n" << name << " Transition Matrix:\n";
        std::cout << "     ";
        for (int j = 0; j < size; ++j) {
            std::cout << "  S" << j << "  ";
        }
        std::cout << "\n";
        
        for (int i = 0; i < size; ++i) {
            std::cout << "S" << i << " [";
            for (int j = 0; j < size; ++j) {
                std::cout << std::fixed << std::setprecision(2) << std::setw(5) << matrix[i][j];
            }
            std::cout << " ]\n";
        }
    }
};

// ============================================================================
// State Set Classes
// ============================================================================

class UniversalSet {
public:
    std::string name;
    int current_state;
    TransitionMatrix transition_matrix;
    std::vector<int> state_history;
    std::shared_ptr<tf::FloatCognitiveTensor> state_tensor;
    
    UniversalSet(const std::string& n) 
        : name(n), current_state(0), transition_matrix(NUM_UNIVERSAL_STATES) {
        initialize_transition_matrix();
        state_history.push_back(current_state);
        
        // Create cognitive tensor for state representation
        state_tensor = std::make_shared<tf::FloatCognitiveTensor>(
            tf::CognitiveTensorShape{NUM_UNIVERSAL_STATES}, 0.0f);
        update_state_tensor();
    }
    
    void initialize_transition_matrix() {
        // Universal set transition probabilities
        transition_matrix.set(0, 0, 0.1f); transition_matrix.set(0, 1, 0.4f);
        transition_matrix.set(0, 2, 0.3f); transition_matrix.set(0, 3, 0.1f);
        transition_matrix.set(0, 4, 0.1f);
        
        transition_matrix.set(1, 0, 0.2f); transition_matrix.set(1, 1, 0.2f);
        transition_matrix.set(1, 2, 0.3f); transition_matrix.set(1, 3, 0.2f);
        transition_matrix.set(1, 4, 0.1f);
        
        transition_matrix.set(2, 0, 0.1f); transition_matrix.set(2, 1, 0.2f);
        transition_matrix.set(2, 2, 0.2f); transition_matrix.set(2, 3, 0.3f);
        transition_matrix.set(2, 4, 0.2f);
        
        transition_matrix.set(3, 0, 0.1f); transition_matrix.set(3, 1, 0.1f);
        transition_matrix.set(3, 2, 0.2f); transition_matrix.set(3, 3, 0.3f);
        transition_matrix.set(3, 4, 0.3f);
        
        transition_matrix.set(4, 0, 0.2f); transition_matrix.set(4, 1, 0.1f);
        transition_matrix.set(4, 2, 0.1f); transition_matrix.set(4, 3, 0.2f);
        transition_matrix.set(4, 4, 0.4f);
        
        transition_matrix.normalize();
    }
    
    void update_state_tensor() {
        // One-hot encoding of current state
        auto& data = state_tensor->data();
        for (int i = 0; i < NUM_UNIVERSAL_STATES; ++i) {
            data[i] = (i == current_state) ? 1.0f : 0.0f;
        }
    }
    
    void transition(std::mt19937& rng) {
        std::uniform_real_distribution<float> dist(0.0f, 1.0f);
        float rand_val = dist(rng);
        
        float cumulative = 0.0f;
        for (int next_state = 0; next_state < NUM_UNIVERSAL_STATES; ++next_state) {
            cumulative += transition_matrix.get(current_state, next_state);
            if (rand_val <= cumulative) {
                current_state = next_state;
                break;
            }
        }
        
        state_history.push_back(current_state);
        update_state_tensor();
    }
};

class ParticularSet {
public:
    std::string name;
    int current_state;
    TransitionMatrix transition_matrix;
    std::vector<int> state_history;
    std::shared_ptr<tf::FloatCognitiveTensor> state_tensor;
    
    ParticularSet(const std::string& n) 
        : name(n), current_state(0), transition_matrix(NUM_PARTICULAR_STATES) {
        initialize_transition_matrix();
        state_history.push_back(current_state);
        
        // Create cognitive tensor for state representation
        state_tensor = std::make_shared<tf::FloatCognitiveTensor>(
            tf::CognitiveTensorShape{NUM_PARTICULAR_STATES}, 0.0f);
        update_state_tensor();
    }
    
    void initialize_transition_matrix() {
        // Particular set transition probabilities
        transition_matrix.set(0, 0, 0.3f); transition_matrix.set(0, 1, 0.4f);
        transition_matrix.set(0, 2, 0.2f); transition_matrix.set(0, 3, 0.1f);
        
        transition_matrix.set(1, 0, 0.2f); transition_matrix.set(1, 1, 0.3f);
        transition_matrix.set(1, 2, 0.3f); transition_matrix.set(1, 3, 0.2f);
        
        transition_matrix.set(2, 0, 0.1f); transition_matrix.set(2, 1, 0.2f);
        transition_matrix.set(2, 2, 0.4f); transition_matrix.set(2, 3, 0.3f);
        
        transition_matrix.set(3, 0, 0.2f); transition_matrix.set(3, 1, 0.2f);
        transition_matrix.set(3, 2, 0.2f); transition_matrix.set(3, 3, 0.4f);
        
        transition_matrix.normalize();
    }
    
    void update_state_tensor() {
        // One-hot encoding of current state
        auto& data = state_tensor->data();
        for (int i = 0; i < NUM_PARTICULAR_STATES; ++i) {
            data[i] = (i == current_state) ? 1.0f : 0.0f;
        }
    }
    
    void transition(std::mt19937& rng) {
        std::uniform_real_distribution<float> dist(0.0f, 1.0f);
        float rand_val = dist(rng);
        
        float cumulative = 0.0f;
        for (int next_state = 0; next_state < NUM_PARTICULAR_STATES; ++next_state) {
            cumulative += transition_matrix.get(current_state, next_state);
            if (rand_val <= cumulative) {
                current_state = next_state;
                break;
            }
        }
        
        state_history.push_back(current_state);
        update_state_tensor();
    }
};

// ============================================================================
// System 4 State Machine
// ============================================================================

class System4StateMachine {
public:
    UniversalSet u1{"U1"};
    UniversalSet u2{"U2"};
    ParticularSet p1{"P1"};
    ParticularSet p2{"P2"};
    ParticularSet p3{"P3"};
    
    std::mt19937 rng;
    int current_time;
    
    System4StateMachine(unsigned int seed = 42) : rng(seed), current_time(0) {}
    
    void step(tf::Taskflow& taskflow) {
        // Determine which sets should transition at this time step
        bool u1_active = should_universal_1_step(current_time);
        bool u2_active = should_universal_2_step(current_time);
        bool p1_active = should_particular_1_step(current_time);
        bool p2_active = should_particular_2_step(current_time);
        bool p3_active = should_particular_3_step(current_time);
        
        // Create parallel tasks for concurrent transitions
        std::vector<tf::Task> transition_tasks;
        
        if (u1_active) {
            auto task = taskflow.emplace([this]() {
                u1.transition(rng);
            }).name("U1_transition");
            transition_tasks.push_back(task);
        }
        
        if (u2_active) {
            auto task = taskflow.emplace([this]() {
                u2.transition(rng);
            }).name("U2_transition");
            transition_tasks.push_back(task);
        }
        
        if (p1_active) {
            auto task = taskflow.emplace([this]() {
                p1.transition(rng);
            }).name("P1_transition");
            transition_tasks.push_back(task);
        }
        
        if (p2_active) {
            auto task = taskflow.emplace([this]() {
                p2.transition(rng);
            }).name("P2_transition");
            transition_tasks.push_back(task);
        }
        
        if (p3_active) {
            auto task = taskflow.emplace([this]() {
                p3.transition(rng);
            }).name("P3_transition");
            transition_tasks.push_back(task);
        }
        
        current_time++;
    }
    
    // Universal sets: alternate double steps
    // U1 steps at: 0,1, 4,5, 8,9, 12,13, 16,17...
    // U2 steps at: 2,3, 6,7, 10,11, 14,15, 18,19...
    bool should_universal_1_step(int t) const {
        int cycle_pos = t % 4;
        return (cycle_pos == 0 || cycle_pos == 1);
    }
    
    bool should_universal_2_step(int t) const {
        int cycle_pos = t % 4;
        return (cycle_pos == 2 || cycle_pos == 3);
    }
    
    // Particular sets: 4 steps apart, offset by 1
    // P1 steps at: 0, 4, 8, 12, 16...
    // P2 steps at: 1, 5, 9, 13, 17...
    // P3 steps at: 2, 6, 10, 14, 18...
    bool should_particular_1_step(int t) const {
        return (t % 4 == 0);
    }
    
    bool should_particular_2_step(int t) const {
        return (t % 4 == 1);
    }
    
    bool should_particular_3_step(int t) const {
        return (t % 4 == 2);
    }
    
    void print_current_state() const {
        std::cout << "t=" << std::setw(3) << current_time << ": "
                  << "U1=S" << u1.current_state << " "
                  << "U2=S" << u2.current_state << " "
                  << "P1=S" << p1.current_state << " "
                  << "P2=S" << p2.current_state << " "
                  << "P3=S" << p3.current_state << "\n";
    }
    
    void print_transition_schedule(int max_time) const {
        std::cout << "\n" << std::string(80, '=') << "\n";
        std::cout << "System 4 Transition Schedule (0 to " << max_time << ")\n";
        std::cout << std::string(80, '=') << "\n";
        
        std::cout << "\nTime: ";
        for (int t = 0; t <= max_time; ++t) {
            std::cout << std::setw(3) << t;
        }
        std::cout << "\n";
        
        std::cout << "U1:   ";
        for (int t = 0; t <= max_time; ++t) {
            std::cout << (should_universal_1_step(t) ? "  X" : "  -");
        }
        std::cout << "\n";
        
        std::cout << "U2:   ";
        for (int t = 0; t <= max_time; ++t) {
            std::cout << (should_universal_2_step(t) ? "  X" : "  -");
        }
        std::cout << "\n";
        
        std::cout << "P1:   ";
        for (int t = 0; t <= max_time; ++t) {
            std::cout << (should_particular_1_step(t) ? "  X" : "  -");
        }
        std::cout << "\n";
        
        std::cout << "P2:   ";
        for (int t = 0; t <= max_time; ++t) {
            std::cout << (should_particular_2_step(t) ? "  X" : "  -");
        }
        std::cout << "\n";
        
        std::cout << "P3:   ";
        for (int t = 0; t <= max_time; ++t) {
            std::cout << (should_particular_3_step(t) ? "  X" : "  -");
        }
        std::cout << "\n\n";
    }
    
    void print_state_history() const {
        std::cout << "\n" << std::string(80, '=') << "\n";
        std::cout << "State History\n";
        std::cout << std::string(80, '=') << "\n\n";
        
        int max_len = std::max({u1.state_history.size(), u2.state_history.size(),
                                p1.state_history.size(), p2.state_history.size(),
                                p3.state_history.size()});
        
        std::cout << "Time  U1  U2  P1  P2  P3\n";
        std::cout << std::string(30, '-') << "\n";
        
        for (size_t t = 0; t < max_len; ++t) {
            std::cout << std::setw(4) << t << "  ";
            
            if (t < u1.state_history.size())
                std::cout << "S" << u1.state_history[t] << "  ";
            else
                std::cout << "--  ";
                
            if (t < u2.state_history.size())
                std::cout << "S" << u2.state_history[t] << "  ";
            else
                std::cout << "--  ";
                
            if (t < p1.state_history.size())
                std::cout << "S" << p1.state_history[t] << "  ";
            else
                std::cout << "--  ";
                
            if (t < p2.state_history.size())
                std::cout << "S" << p2.state_history[t] << "  ";
            else
                std::cout << "--  ";
                
            if (t < p3.state_history.size())
                std::cout << "S" << p3.state_history[t];
            
            std::cout << "\n";
        }
    }
};

// ============================================================================
// Main Simulation
// ============================================================================

int main() {
    std::cout << "\n" << std::string(80, '=') << "\n";
    std::cout << "System 4 State Transition Matrix Simulation\n";
    std::cout << "Using CogTaskFlow for Parallel Processing\n";
    std::cout << std::string(80, '=') << "\n";
    
    // Create System 4 state machine
    System4StateMachine system4;
    
    // Print transition matrices
    system4.u1.transition_matrix.print("Universal Set (U1/U2)");
    system4.p1.transition_matrix.print("Particular Set (P1/P2/P3)");
    
    // Print transition schedule
    const int SIMULATION_STEPS = 24;
    system4.print_transition_schedule(SIMULATION_STEPS);
    
    // Create taskflow executor
    tf::Executor executor;
    
    std::cout << "Running simulation for " << SIMULATION_STEPS << " time steps...\n\n";
    
    // Run simulation
    for (int t = 0; t < SIMULATION_STEPS; ++t) {
        tf::Taskflow taskflow;
        system4.step(taskflow);
        executor.run(taskflow).wait();
        system4.print_current_state();
    }
    
    // Print final state history
    system4.print_state_history();
    
    // Analyze state distributions
    std::cout << "\n" << std::string(80, '=') << "\n";
    std::cout << "State Distribution Analysis\n";
    std::cout << std::string(80, '=') << "\n\n";
    
    auto analyze_distribution = [](const std::string& name, 
                                   const std::vector<int>& history, 
                                   int num_states) {
        std::vector<int> counts(num_states, 0);
        for (int state : history) {
            counts[state]++;
        }
        
        std::cout << name << " state distribution:\n";
        for (int i = 0; i < num_states; ++i) {
            float percentage = 100.0f * counts[i] / history.size();
            std::cout << "  S" << i << ": " << std::setw(3) << counts[i] 
                      << " (" << std::fixed << std::setprecision(1) 
                      << std::setw(5) << percentage << "%)\n";
        }
        std::cout << "\n";
    };
    
    analyze_distribution("U1", system4.u1.state_history, NUM_UNIVERSAL_STATES);
    analyze_distribution("U2", system4.u2.state_history, NUM_UNIVERSAL_STATES);
    analyze_distribution("P1", system4.p1.state_history, NUM_PARTICULAR_STATES);
    analyze_distribution("P2", system4.p2.state_history, NUM_PARTICULAR_STATES);
    analyze_distribution("P3", system4.p3.state_history, NUM_PARTICULAR_STATES);
    
    std::cout << std::string(80, '=') << "\n";
    std::cout << "Simulation Complete\n";
    std::cout << std::string(80, '=') << "\n\n";
    
    return 0;
}
