
#include <vector>
#include <memory>
#include <array>
#include <functional>
#include <algorithm>
#include <type_traits>
#include <unordered_map>
#include <chrono>
#include <thread>
#include <random>
#include "../core/taskflow.hpp"

/**
@file cognitive_tensor.hpp
@brief cognitive tensor data structures for knowledge representation
*/

namespace tf {

// Forward declarations
class CognitiveTensor;
template<typename T> class TypedCognitiveTensor;

/**
@enum CognitiveDataType
@brief Enumeration of cognitive data types supported by tensors
*/
enum class CognitiveDataType {
  FLOAT32,
  FLOAT64, 
  INT32,
  INT64,
  BOOL,
  STRING,
  SYMBOL,
  ATOM_ID
};

/**
@struct CognitiveTensorShape
@brief Represents the multi-dimensional shape of a cognitive tensor
*/
struct CognitiveTensorShape {
  std::vector<size_t> dimensions;
  
  CognitiveTensorShape() = default;
  
  CognitiveTensorShape(std::initializer_list<size_t> dims) : dimensions(dims) {}
  
  template<typename... Args>
  CognitiveTensorShape(Args... args) : dimensions{static_cast<size_t>(args)...} {}
  
  size_t rank() const { return dimensions.size(); }
  
  size_t total_size() const {
    size_t size = 1;
    for(auto dim : dimensions) size *= dim;
    return size;
  }
  
  bool operator==(const CognitiveTensorShape& other) const {
    return dimensions == other.dimensions;
  }
  
  bool operator!=(const CognitiveTensorShape& other) const {
    return !(*this == other);
  }
};

/**
@class CognitiveTensorMetadata
@brief Stores metadata associated with cognitive tensors
*/
class CognitiveTensorMetadata {
public:
  std::string name;
  float attention_value = 0.0f;
  float strength_value = 1.0f; 
  float confidence_value = 1.0f;
  uint64_t creation_time = 0;
  uint64_t last_access_time = 0;
  std::unordered_map<std::string, std::string> tags;
  
  CognitiveTensorMetadata() = default;
  
  CognitiveTensorMetadata(const std::string& n) : name(n) {}
  
  void update_access_time() {
    last_access_time = std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()
    ).count();
  }
};

/**
@class CognitiveTensor
@brief Base class for multi-dimensional cognitive data structures
*/
class CognitiveTensor {
public:
  CognitiveTensor(CognitiveDataType type, const CognitiveTensorShape& shape)
    : _data_type(type), _shape(shape), _metadata(std::make_shared<CognitiveTensorMetadata>()) {
    _metadata->creation_time = std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::system_clock::now().time_since_epoch()
    ).count();
  }
  
  virtual ~CognitiveTensor() = default;
  
  CognitiveDataType data_type() const { return _data_type; }
  const CognitiveTensorShape& shape() const { return _shape; }
  std::shared_ptr<CognitiveTensorMetadata> metadata() { return _metadata; }
  const std::shared_ptr<CognitiveTensorMetadata> metadata() const { return _metadata; }
  
  virtual void* raw_data() = 0;
  virtual const void* raw_data() const = 0;
  virtual size_t size_in_bytes() const = 0;
  
  virtual std::unique_ptr<CognitiveTensor> clone() const = 0;
  
  // Cognitive operations
  void update_attention(float value) {
    _metadata->attention_value = std::max(0.0f, std::min(1.0f, value));
    _metadata->update_access_time();
  }
  
  float get_attention() const { return _metadata->attention_value; }
  
  void update_strength(float value) {
    _metadata->strength_value = std::max(0.0f, std::min(1.0f, value));
  }
  
  float get_strength() const { return _metadata->strength_value; }
  
  void update_confidence(float value) {
    _metadata->confidence_value = std::max(0.0f, std::min(1.0f, value));
  }
  
  float get_confidence() const { return _metadata->confidence_value; }
  
  // Cognitive importance score combining attention, strength, and confidence
  float cognitive_importance() const {
    return (_metadata->attention_value * 0.4f + 
            _metadata->strength_value * 0.3f + 
            _metadata->confidence_value * 0.3f);
  }
  
protected: