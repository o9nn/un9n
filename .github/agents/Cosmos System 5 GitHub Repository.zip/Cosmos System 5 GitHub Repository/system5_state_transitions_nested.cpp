/**
 * @brief System 5 Deterministic State Transition Implementation with Nested Concurrency
 * 
 * This implementation models the hypothesized System 5 structure (7 sets: 3 Universal, 4 Particular)
 * with a 60-step cycle, implementing the nested concurrency for the Particular Sets using 
 * CogTaskFlow's task dependency features.
 */

#include <taskflow/taskflow.hpp>
#include <taskflow/cognitive/cognitive.hpp>
#include <iostream>
#include <vector>
#include <array>
#include <string>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <map>

// ============================================================================
// State Definitions and Sequences
// ============================================================================

const int SIMULATION_STEPS = 60; // LCM of 3 (Universal cycle) and 20 (Particular cycle)

// Universal Set Sequences (3-step cycle)
const std::array<std::string, 3> U_STATES = {"U-P", "U-S", "U-T"}; // Primary, Secondary, Tertiary Universal

// Particular Set States (4 states, represented by integers 0-3)
const int P_NUM_STATES = 4;

// ============================================================================
// State Set Classes
// ============================================================================

class UniversalSet {
public:
    std::string name;
    std::string current_state;
    std::vector<std::string> state_history;
    
    UniversalSet(const std::string& n) : name(n) {
        current_state = U_STATES[0];
        state_history.push_back(current_state);
    }
    
    void transition(int time_step) {
        // U1 transitions at t % 3 == 0, U2 at t % 3 == 1, U3 at t % 3 == 2
        int next_index = time_step % 3;
        current_state = U_STATES[next_index];
        state_history.push_back(current_state);
    }
};

class ParticularSet {
public:
    std::string name;
    int current_state; // State is an integer 0-3
    std::vector<int> state_history;
    
    ParticularSet(const std::string& n) : name(n), current_state(0) {
        state_history.push_back(current_state);
    }
    
    // The transition logic is now external, defined by the nested concurrency
    void update_state(int new_state) {
        current_state = new_state;
        state_history.push_back(current_state);
    }
};

// ============================================================================
// System 5 State Machine
// ============================================================================

class System5StateMachine {
public:
    UniversalSet u1{"U1"};
    UniversalSet u2{"U2"};
    UniversalSet u3{"U3"};
    ParticularSet p1{"P1"};
    ParticularSet p2{"P2"};
    ParticularSet p3{"P3"};
    ParticularSet p4{"P4"};
    
    std::array<ParticularSet*, 4> p_sets = {&p1, &p2, &p3, &p4};
    
    int current_time;
    
    System5StateMachine() : current_time(0) {}
    
    // Logic to determine if a Particular Set should transition at this step
    bool should_particular_step(int t, int set_index) const {
        // P1 at t % 5 == 0, P2 at t % 5 == 1, P3 at t % 5 == 2, P4 at t % 5 == 3
        return (t % 5 == set_index);
    }
    
    void step(tf::Taskflow& taskflow) {
        // --- 1. Universal Set Transitions (Independent) ---
        taskflow.emplace([this]() { u1.transition(current_time); }).name("U1_Trans");
        taskflow.emplace([this]() { u2.transition(current_time); }).name("U2_Trans");
        taskflow.emplace([this]() { u3.transition(current_time); }).name("U3_Trans");
        
        // --- 2. Particular Set Transitions (Nested Concurrency) ---
        
        // Read current states of all Particular Sets
        std::array<int, 4> current_p_states;
        std::array<tf::Task, 4> read_tasks;
        
        for (int i = 0; i < 4; ++i) {
            read_tasks[i] = taskflow.emplace([this, i, &current_p_states]() {
                current_p_states[i] = p_sets[i]->current_state;
            }).name("P" + std::to_string(i+1) + "_Read");
        }
        
        // Calculate next state for each Particular Set
        for (int i = 0; i < 4; ++i) {
            if (should_particular_step(current_time, i)) {
                
                // The transition task depends on the read tasks of ALL other sets
                auto transition_task = taskflow.emplace([this, i, &current_p_states]() {
                    
                    // The "Convolution Function" (Revised to include Universal Set influence)
                    int sum_of_others = 0;
                    for (int j = 0; j < 4; ++j) {
                        if (i != j) {
                            sum_of_others += current_p_states[j];
                        }
                    }
                    
                    // U_Index(t) = (current_time % 3)
                    int u_index = current_time % 3;
                    
                    // S_i(t+1) = (S_i(t) + sum(S_j(t)) + U_idx(t)) mod 4
                    int next_state = (p_sets[i]->current_state + sum_of_others + u_index) % P_NUM_STATES;
                    
                    p_sets[i]->update_state(next_state);
                    
                }).name("P" + std::to_string(i+1) + "_Trans");
                
                // Set dependencies: P_i_Trans depends on P_j_Read for all j != i
                for (int j = 0; j < 4; ++j) {
                    if (i != j) {
                        transition_task.succeed(read_tasks[j]);
                    }
                }
            } else {
                // If not transitioning, simply update history with current state
                taskflow.emplace([this, i]() {
                    p_sets[i]->state_history.push_back(p_sets[i]->current_state);
                }).name("P" + std::to_string(i+1) + "_NoTrans");
            }
        }
        
        current_time++;
    }
    
    void print_current_state() const {
        std::cout << "t=" << std::setw(3) << current_time << ": "
                  << "U1=" << std::setw(3) << u1.current_state << " "
                  << "U2=" << std::setw(3) << u2.current_state << " "
                  << "U3=" << std::setw(3) << u3.current_state << " "
                  << "P1=" << std::setw(3) << p1.current_state << " "
                  << "P2=" << std::setw(3) << p2.current_state << " "
                  << "P3=" << std::setw(3) << p3.current_state << " "
                  << "P4=" << std::setw(3) << p4.current_state << "\n";
    }
    
    void print_state_history() const {
        std::cout << "\n" << std::string(100, '=') << "\n";
        std::cout << "System 5 State History (Cycle Length: " << SIMULATION_STEPS << ")\n";
        std::cout << std::string(100, '=') << "\n\n";
        
        int max_len = u1.state_history.size();
        
        std::cout << "Time  U1   U2   U3   P1   P2   P3   P4\n";
        std::cout << std::string(40, '-') << "\n";
        
        for (size_t t = 0; t < max_len; ++t) {
            std::cout << std::setw(4) << t << "  ";
            
            std::cout << std::setw(3) << u1.state_history[t] << "  ";
            std::cout << std::setw(3) << u2.state_history[t] << "  ";
            std::cout << std::setw(3) << u3.state_history[t] << "  ";
            
            std::cout << std::setw(3) << p1.state_history[t] << "  ";
            std::cout << std::setw(3) << p2.state_history[t] << "  ";
            std::cout << std::setw(3) << p3.state_history[t] << "  ";
            std::cout << std::setw(3) << p4.state_history[t];
            
            std::cout << "\n";
        }
    }
};

// ============================================================================
// Main Simulation
// ============================================================================

int main() {
    std::cout << "\n" << std::string(100, '=') << "\n";
    std::cout << "System 5 Deterministic State Transition Simulation with Nested Concurrency\n";
    std::cout << "Using CogTaskFlow for Parallel Processing and Task Dependencies\n";
    std::cout << std::string(100, '=') << "\n";
    
    // Create System 5 state machine
    System5StateMachine system5;
    
    // Create taskflow executor
    tf::Executor executor;
    
    std::cout << "Running simulation for " << SIMULATION_STEPS << " time steps...\n\n";
    
    // Run simulation
    for (int t = 0; t < SIMULATION_STEPS; ++t) {
        tf::Taskflow taskflow;
        system5.step(taskflow);
        executor.run(taskflow).wait();
        system5.print_current_state();
    }
    
    // Print final state history
    system5.print_state_history();
    
    std::cout << std::string(100, '=') << "\n";
    std::cout << "Simulation Complete\n";
    std::cout << std::string(100, '=') << "\n\n";
    
    return 0;
}
