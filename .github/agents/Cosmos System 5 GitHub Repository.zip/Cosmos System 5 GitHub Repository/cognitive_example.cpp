/**
 * @brief OpenCog Cognitive Tensor Architecture Example
 * 
 * This example demonstrates the key features of the cognitive architecture:
 * - Creating cognitive tensors for neural representations
 * - Building knowledge graphs with AtomSpace
 * - Parallel cognitive processing with attention management
 * - Pattern recognition and reasoning
 */

#include <taskflow/taskflow.hpp>
#include <taskflow/cognitive/cognitive.hpp>
#include <iostream>
#include <chrono>
#include <random>

void print_separator(const std::string& title) {
  std::cout << "\n" << std::string(60, '=') << "\n";
  std::cout << "  " << title << "\n";
  std::cout << std::string(60, '=') << "\n";
}

int main() {
  print_separator("OpenCog Cognitive Tensor Architecture Demo");
  
  // Create cognitive executor with 8 workers and attention capacity of 200
  tf::CognitiveExecutor cognitive_executor(8, 200.0f);
  cognitive_executor.start();
  
  auto start_time = std::chrono::high_resolution_clock::now();
  
  // Get access to the atom space
  auto space = cognitive_executor.atom_space();
  
  print_separator("1. Creating Knowledge Base");
  
  // Create concepts with cognitive tensors
  std::cout << "Creating concepts with neural representations...\n";
  
  auto human_tensor = std::make_shared<tf::FloatCognitiveTensor>(
    tf::CognitiveTensorShape{10, 10}, 0.0f);
  auto animal_tensor = std::make_shared<tf::FloatCognitiveTensor>(
    tf::CognitiveTensorShape{10, 10}, 0.0f);
  auto mammal_tensor = std::make_shared<tf::FloatCognitiveTensor>(
    tf::CognitiveTensorShape{10, 10}, 0.0f);
  
  // Initialize tensors with random values
  std::random_device rd;
  std::mt19937 gen(rd());
  std::normal_distribution<float> dist(0.0f, 0.1f);
  
  for (auto& val : human_tensor->data()) val = dist(gen) + 0.7f;  // Human features
  for (auto& val : animal_tensor->data()) val = dist(gen) + 0.5f;  // Animal features  
  for (auto& val : mammal_tensor->data()) val = dist(gen) + 0.6f;  // Mammal features
  
  // Create concept atoms with tensors
  auto human = tf::cognitive::create_concept(*space, "Human", human_tensor);
  auto animal = tf::cognitive::create_concept(*space, "Animal", animal_tensor);
  auto mammal = tf::cognitive::create_concept(*space, "Mammal", mammal_tensor);
  auto dog = tf::cognitive::create_concept(*space, "Dog");
  auto cat = tf::cognitive::create_concept(*space, "Cat");
  auto socrates = tf::cognitive::create_concept(*space, "Socrates");
  
  std::cout << "Created " << space->size() << " atoms\n";
  
  // Create relationships
  std::cout << "Building knowledge relationships...\n";
  
  auto human_is_mammal = tf::cognitive::create_inheritance(*space, human, mammal, 0.95f, 0.9f);
  auto mammal_is_animal = tf::cognitive::create_inheritance(*space, mammal, animal, 1.0f, 0.95f);
  auto dog_is_mammal = tf::cognitive::create_inheritance(*space, dog, mammal, 0.98f, 0.95f);
  auto cat_is_mammal = tf::cognitive::create_inheritance(*space, cat, mammal, 0.98f, 0.95f);
  auto socrates_is_human = tf::cognitive::create_inheritance(*space, socrates, human, 1.0f, 1.0f);
  
  // Create similarity relationships
  auto dog_cat_similarity = tf::cognitive::create_similarity(*space, dog, cat, 0.7f, 0.8f);
  
  // Create predicates and evaluations
  auto mortal_predicate = space->add_atom(tf::AtomType::PREDICATE_NODE, "mortal");
  auto intelligent_predicate = space->add_atom(tf::AtomType::PREDICATE_NODE, "intelligent");
  
  auto humans_mortal = tf::cognitive::create_evaluation(*space, mortal_predicate, {human}, 0.99f, 0.95f);
  auto humans_intelligent = tf::cognitive::create_evaluation(*space, intelligent_predicate, {human}, 0.9f, 0.8f);
  
  std::cout << "Knowledge base now contains " << space->size() << " atoms\n";
  
  print_separator("2. Parallel Cognitive Processing");
  
  // Set initial attention values
  std::cout << "Setting initial attention values...\n";
  human->set_attention(0.8f);
  socrates->set_attention(0.9f);
  dog->set_attention(0.6f);
  cat->set_attention(0.6f);
  
  // Parallel attention spreading
  std::cout << "Spreading attention across knowledge graph...\n";
  auto attention_future = cognitive_executor.spread_attention(0.92f);
  attention_future.wait();
  
  // Update attention based on cognitive importance
  std::cout << "Updating attention based on importance...\n";
  auto importance_future = cognitive_executor.update_atom_attention([](auto atom) {
    return atom->cognitive_importance() * 0.8f + 0.1f;
  });
  importance_future.wait();
  
  print_separator("3. Cognitive Tensor Operations");
  
  // Apply neural transformations to cognitive tensors
  std::cout << "Applying transformations to cognitive tensors...\n";
  
  // Apply transformations using TaskFlow directly
  tf::Taskflow tensor_taskflow;
  
  human_tensor->apply_parallel(tensor_taskflow, [](float x) { return std::tanh(x * 1.2f); });
  animal_tensor->apply_parallel(tensor_taskflow, [](float x) { return 1.0f / (1.0f + std::exp(-(x + 0.1f))); });
  mammal_tensor->apply_parallel(tensor_taskflow, [](float x) { return std::max(0.0f, x); }); // ReLU
  
  // Run transformations
  tf::Executor tensor_executor;
  tensor_executor.run(tensor_taskflow).wait();
  
  // Compute tensor similarities
  std::cout << "Computing cognitive tensor similarities...\n";
  
  // Compute norm using TaskFlow reduce
  tf::Taskflow norm_taskflow;
  float human_norm_squared;
  human_tensor->reduce_parallel(norm_taskflow, human_norm_squared, 0.0f, 
                              [](float acc, float x) { return acc + x * x; });
  
  tf::Executor norm_executor;
  norm_executor.run(norm_taskflow).wait();
  
  float human_norm = std::sqrt(human_norm_squared);
  std::cout << "Human tensor norm: " << human_norm << "\n";
  
  print_separator("4. Pattern Recognition and Reasoning");
  
  // Find high-attention concepts
  std::cout << "Finding high-attention concepts...\n";
  auto pattern_future = cognitive_executor.find_patterns([](auto atom) {
    return atom->type() == tf::AtomType::CONCEPT_NODE && atom->attention() > 0.5f;
  });
  
  auto high_attention_concepts = pattern_future.get();
  std::cout << "Found " << high_attention_concepts.size() << " high-attention concepts:\n";
  for (const auto& atom_concept : high_attention_concepts) {
    std::cout << "  - " << atom_concept->name() << " (attention: " 
              << atom_concept->attention() << ", importance: " 
              << atom_concept->cognitive_importance() << ")\n";
  }
  
  // Pattern-based reasoning using TaskFlow
  std::cout << "\nPerforming logical reasoning...\n";
  tf::Taskflow reasoning_taskflow;
  
  // Create inference: If Socrates is Human and Human is Mortal, then Socrates is Mortal
  auto socrates_mortal = tf::cognitive::create_evaluation(*space, mortal_predicate, {socrates});
  
  tf::cognitive::create_reasoning_task(
    reasoning_taskflow, *space, 
    {socrates_is_human, humans_mortal}, socrates_mortal,
    [](float a, float b) { return a * b; } // Probabilistic reasoning
  );
  
  cognitive_executor.run_cognitive_taskflow(reasoning_taskflow, tf::CognitiveTaskPriority::HIGH).wait();
  
  std::cout << "Inference result - Socrates is mortal: strength=" 
            << socrates_mortal->strength() << ", confidence=" 
            << socrates_mortal->confidence() << "\n";
  
  print_separator("5. Advanced Cognitive Operations");
  
  // Create a learning pattern recognition task
  std::cout << "Discovering structural patterns...\n";
  
  tf::Taskflow pattern_taskflow;
  std::vector<std::vector<std::shared_ptr<tf::Atom>>> discovered_patterns;
  
  tf::cognitive::create_pattern_learning_task(
    pattern_taskflow, *space, discovered_patterns);
  
  cognitive_executor.run_cognitive_taskflow(pattern_taskflow, tf::CognitiveTaskPriority::NORMAL).wait();
  
  std::cout << "Discovered " << discovered_patterns.size() << " structural patterns:\n";
  for (size_t i = 0; i < discovered_patterns.size(); ++i) {
    std::cout << "  Pattern " << (i+1) << ": ";
    for (const auto& atom : discovered_patterns[i]) {
      if (!atom->name().empty()) {
        std::cout << atom->name() << " ";
      }
    }
    std::cout << "(" << discovered_patterns[i].size() << " atoms)\n";
  }
  
  // Memory management - forget low-importance atoms
  std::cout << "\nPerforming cognitive memory management...\n";
  size_t before_cleanup = space->size();
  
  auto cleanup_future = cognitive_executor.forget_unimportant_atoms(0.05f);
  cleanup_future.wait();
  
  size_t after_cleanup = space->size();
  std::cout << "Memory cleanup: " << before_cleanup << " -> " << after_cleanup 
            << " atoms (removed " << (before_cleanup - after_cleanup) << ")\n";
  
  print_separator("6. System Status and Performance");
  
  auto end_time = std::chrono::high_resolution_clock::now();
  auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
  
  std::cout << "Execution time: " << duration.count() << " ms\n";
  std::cout << "Final atom count: " << cognitive_executor.atom_count() << "\n";
  std::cout << "Attention utilization: " << 
               (cognitive_executor.attention_utilization() * 100.0f) << "%\n";
  std::cout << "Available attention: " << cognitive_executor.available_attention() << "\n";
  
  // Display some high-importance atoms
  std::cout << "\nTop cognitive atoms by importance:\n";
  auto all_atoms = space->get_atoms_by_attention(0.0f, 1.0f);
  std::sort(all_atoms.begin(), all_atoms.end(), 
    [](const auto& a, const auto& b) {
      return a->cognitive_importance() > b->cognitive_importance();
    });
  
  for (size_t i = 0; i < std::min(size_t{5}, all_atoms.size()); ++i) {
    const auto& atom = all_atoms[i];
    std::cout << "  " << (i+1) << ". " << atom->name() 
              << " (importance: " << atom->cognitive_importance() 
              << ", attention: " << atom->attention() << ")\n";
  }
  
  print_separator("7. Cognitive Architecture Summary");
  
  std::cout << "Successfully demonstrated:\n";
  std::cout << "✓ Cognitive tensor creation and parallel processing\n";
  std::cout << "✓ AtomSpace knowledge graph construction\n";
  std::cout << "✓ Parallel attention spreading and management\n";
  std::cout << "✓ Pattern recognition and logical reasoning\n";
  std::cout << "✓ Heterogeneous task graph computing\n";
  std::cout << "✓ Memory management and cognitive resource allocation\n";
  std::cout << "✓ Integration of OpenCog principles with TaskFlow parallelism\n";
  
  // Cleanup
  cognitive_executor.wait_for_all();
  cognitive_executor.stop();
  
  print_separator("Demo Complete");
  
  return 0;
}

