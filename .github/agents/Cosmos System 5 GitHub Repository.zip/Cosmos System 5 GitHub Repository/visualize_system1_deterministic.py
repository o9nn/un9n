#!/usr/bin/env python3
"""
System 1 Deterministic State Transition Visualization
Generates visual representations of the deterministic state sequences
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from matplotlib.colors import ListedColormap

def plot_deterministic_schedule():
    """Plot the deterministic state sequences as a timeline"""
    
    CYCLE_LENGTH = 1
    SIMULATION_STEPS = CYCLE_LENGTH * 10
    
    # Universal Set Sequence (1 step)
    U1_SEQUENCE = ["1E"]
    
    all_sequences = [U1_SEQUENCE]
    set_names = ["U1"]
    
    # Extend sequences for the full simulation length
    extended_sequences = []
    for seq in all_sequences:
        extended_sequences.append(seq * (SIMULATION_STEPS // CYCLE_LENGTH + 1))
        
    # Map all unique states to colors
    unique_states = sorted(list(set(state for seq in extended_sequences for state in seq)))
    num_states = len(unique_states)
    
    # Create a colormap
    cmap = plt.cm.get_cmap('Set1', num_states)
    state_to_color = {state: cmap(i) for i, state in enumerate(unique_states)}
    
    fig, ax = plt.subplots(figsize=(10, 2))
    
    # Plot each set's sequence
    for i, (set_name, seq) in enumerate(zip(set_names, extended_sequences)):
        y_pos = len(set_names) - i - 1
        
        for t in range(SIMULATION_STEPS + 1):
            state = seq[t]
            color = state_to_color[state]
            
            rect = mpatches.Rectangle((t - 0.5, y_pos - 0.4), 1.0, 0.8,
                                      facecolor=color, edgecolor='black', linewidth=0.5)
            ax.add_patch(rect)
            
            # Add state label
            ax.text(t, y_pos, state, ha='center', va='center', fontsize=10, color='black', fontweight='bold')
    
    # Formatting
    ax.set_xlim(-1, SIMULATION_STEPS + 1)
    ax.set_ylim(-1, len(set_names))
    ax.set_yticks(range(len(set_names)))
    ax.set_yticklabels(set_names[::-1], fontsize=12, fontweight='bold')
    ax.set_xticks(range(SIMULATION_STEPS + 1))
    ax.set_xlabel('Time Step (t)', fontsize=14, fontweight='bold')
    ax.set_title('System 1 Deterministic State Transition Timeline (10 Cycles)', 
                 fontsize=16, fontweight='bold', pad=20)
    ax.grid(True, axis='x', alpha=0.3)
    
    # Add cycle markers
    for cycle in range(1, SIMULATION_STEPS // CYCLE_LENGTH + 1):
        ax.axvline(x=cycle * CYCLE_LENGTH - 0.5, color='red', linestyle='--', linewidth=2, alpha=0.7)
        ax.text(cycle * CYCLE_LENGTH - 0.5, len(set_names) - 0.5, f'Cycle {cycle} End', 
                rotation=90, va='bottom', ha='right', color='red', fontsize=10)
    
    # Create a legend for the states
    legend_patches = [mpatches.Patch(color=state_to_color[state], label=state) for state in unique_states]
    ax.legend(handles=legend_patches, title="States", bbox_to_anchor=(1.05, 1), loc='upper left', ncol=1)
    
    plt.tight_layout(rect=[0, 0, 0.85, 1]) # Adjust layout to make room for legend
    plt.savefig('/home/ubuntu/system1_deterministic_timeline.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: system1_deterministic_timeline.png")
    plt.close()

def main():
    print("\n" + "="*80)
    print("System 1 Deterministic State Transition Visualization")
    print("="*80 + "\n")
    
    print("Generating visualizations...\n")
    
    plot_deterministic_schedule()
    
    print("\n" + "="*80)
    print("All visualizations generated successfully!")
    print("="*80 + "\n")

if __name__ == "__main__":
    main()
