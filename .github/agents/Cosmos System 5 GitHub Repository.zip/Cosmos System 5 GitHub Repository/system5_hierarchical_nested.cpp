/**
 * @brief System 5 Hierarchical Deterministic State Transition Implementation
 * 
 * This model implements the refined System 5 structure:
 * - 4 Synchronous Sets (S1, S2, S3, S4) with a 4-step cycle.
 * - 4 Concurrent Tensor Bundles (T1-T4) with a staggered 5-step cycle.
 * - Each Bundle contains 3 concurrent threads (F1, F2, F3) with nested concurrency logic.
 * 
 * Uses nested CogTaskFlows for hierarchical parallelism.
 */

#include <taskflow/taskflow.hpp>
#include <taskflow/cognitive/cognitive.hpp>
#include <iostream>
#include <vector>
#include <array>
#include <string>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <numeric>

// ============================================================================
// State Definitions
// ============================================================================

const int SIMULATION_STEPS = 60; // LCM of 4 (Sync cycle) and 5 (Bundle stagger)
const int S_NUM_STATES = 4;
const int F_NUM_STATES = 4;

// ============================================================================
// State Set Classes
// ============================================================================

class SynchronousSet {
public:
    std::string name;
    int current_state; // State is an integer 0-3
    std::vector<int> state_history;
    
    SynchronousSet(const std::string& n) : name(n), current_state(0) {
        state_history.push_back(current_state);
    }
    
    void transition(int time_step) {
        // Simple sequential transition: S_i(t+1) = (S_i(t) + 1) mod 4
        current_state = (time_step % S_NUM_STATES);
        state_history.push_back(current_state);
    }
};

class TensorThread {
public:
    std::string name;
    int current_state; // State is an integer 0-3
    std::vector<int> state_history;
    
    TensorThread(const std::string& n) : name(n), current_state(0) {
        state_history.push_back(current_state);
    }
    
    void update_state(int new_state) {
        current_state = new_state;
        state_history.push_back(current_state);
    }
};

// ============================================================================
// Tensor Bundle (Sub-Taskflow Logic)
// ============================================================================

class TensorBundle {
public:
    std::string name;
    std::array<TensorThread, 3> threads = {
        TensorThread("F1"), TensorThread("F2"), TensorThread("F3")
    };
    
    TensorBundle(const std::string& n) : name(n) {}
    
    // The core logic for the Intra-Bundle Concurrency (Level 2)
    void step(tf::Subflow& subflow, int global_influence_state) {
        
        // --- 1. Read current states of all threads in the bundle ---
        std::array<int, 3> current_f_states;
        std::array<tf::Task, 3> read_tasks;
        
        for (int j = 0; j < 3; ++j) {
            read_tasks[j] = subflow.emplace([this, j, &current_f_states]() {
                current_f_states[j] = threads[j].current_state;
            }).name(name + "_F" + std::to_string(j+1) + "_Read");
        }
        
        // --- 2. Calculate next state for each thread (Hierarchical Convolution) ---
        for (int j = 0; j < 3; ++j) {
            
            auto transition_task = subflow.emplace([this, j, global_influence_state, &current_f_states]() {
                
                // Sum of states of the other two threads in the bundle
                int sum_of_others = 0;
                for (int k = 0; k < 3; ++k) {
                    if (j != k) {
                        sum_of_others += current_f_states[k];
                    }
                }
                
                // Transition Function: S_i,j(t+1) = (S_i,j(t) + sum(S_i,k(t)) + S_4(t)) mod 4
                // S_4(t) is passed as global_influence_state
                int next_state = (threads[j].current_state + sum_of_others + global_influence_state) % F_NUM_STATES;
                
                threads[j].update_state(next_state);
                
            }).name(name + "_F" + std::to_string(j+1) + "_Trans");
            
            // Set dependencies: F_j_Trans depends on F_k_Read for all k != j
            for (int k = 0; k < 3; ++k) {
                if (j != k) {
                    transition_task.succeed(read_tasks[k]);
                }
            }
        }
    }
    
    // Logic for when the bundle is inactive
    void no_step() {
        for (int j = 0; j < 3; ++j) {
            threads[j].state_history.push_back(threads[j].current_state);
        }
    }
};

// ============================================================================
// System 5 State Machine (Main Taskflow Logic)
// ============================================================================

class System5StateMachine {
public:
    // Synchronous Sets (S1, S2, S3 are Universal, S4 is Particular)
    SynchronousSet s1{"S1-U"};
    SynchronousSet s2{"S2-U"};
    SynchronousSet s3{"S3-U"};
    SynchronousSet s4{"S4-P"}; // Acts as the global influence
    
    // Concurrent Tensor Bundles
    std::array<TensorBundle, 4> bundles = {
        TensorBundle("T1"), TensorBundle("T2"), TensorBundle("T3"), TensorBundle("T4")
    };
    
    int current_time;
    
    System5StateMachine() : current_time(0) {}
    
    // Logic to determine if a Tensor Bundle should transition at this step
    bool should_bundle_step(int t, int bundle_index) const {
        // T1 at t % 5 == 0, T2 at t % 5 == 1, T3 at t % 5 == 2, T4 at t % 5 == 3
        return (t % 5 == bundle_index);
    }
    
    void step(tf::Taskflow& taskflow) {
        
        // --- 1. Synchronous Set Transitions (Independent) ---
        // S1, S2, S3, S4 all transition every step, but their state is determined by t % 4
        taskflow.emplace([this]() { s1.transition(current_time); }).name("S1_Trans");
        taskflow.emplace([this]() { s2.transition(current_time); }).name("S2_Trans");
        taskflow.emplace([this]() { s3.transition(current_time); }).name("S3_Trans");
        taskflow.emplace([this]() { s4.transition(current_time); }).name("S4_Trans");
        
        // --- 2. Concurrent Tensor Bundles (Inter-Bundle Concurrency) ---
        
        // S4's state acts as the global influence for the Particular Sets
        int global_influence_state = s4.current_state;
        
        for (int i = 0; i < 4; ++i) {
            if (should_bundle_step(current_time, i)) {
                // Bundle is active: run the sub-Taskflow for intra-bundle concurrency
                taskflow.emplace([this, i, global_influence_state](tf::Subflow& subflow) {
                    bundles[i].step(subflow, global_influence_state);
                }).name(bundles[i].name + "_Active");
            } else {
                // Bundle is inactive: simply update history with current state
                taskflow.emplace([this, i]() {
                    bundles[i].no_step();
                }).name(bundles[i].name + "_Inactive");
            }
        }
        
        current_time++;
    }
    
    void print_current_state() const {
        std::cout << "t=" << std::setw(3) << current_time << ": "
                  << "S1=" << std::setw(1) << s1.current_state << " "
                  << "S2=" << std::setw(1) << s2.current_state << " "
                  << "S3=" << std::setw(1) << s3.current_state << " "
                  << "S4=" << std::setw(1) << s4.current_state << " | "
                  << "T1=(" << bundles[0].threads[0].current_state << "," << bundles[0].threads[1].current_state << "," << bundles[0].threads[2].current_state << ") "
                  << "T2=(" << bundles[1].threads[0].current_state << "," << bundles[1].threads[1].current_state << "," << bundles[1].threads[2].current_state << ") "
                  << "T3=(" << bundles[2].threads[0].current_state << "," << bundles[2].threads[1].current_state << "," << bundles[2].threads[2].current_state << ") "
                  << "T4=(" << bundles[3].threads[0].current_state << "," << bundles[3].threads[1].current_state << "," << bundles[3].threads[2].current_state << ")\n";
    }
    
    void print_state_history() const {
        std::cout << "\n" << std::string(150, '=') << "\n";
        std::cout << "System 5 Hierarchical State History (Cycle Length: " << SIMULATION_STEPS << ")\n";
        std::cout << std::string(150, '=') << "\n\n";
        
        int max_len = s1.state_history.size();
        
        std::cout << "Time | S1 S2 S3 S4 | T1(F1 F2 F3) | T2(F1 F2 F3) | T3(F1 F2 F3) | T4(F1 F2 F3)\n";
        std::cout << std::string(70, '-') << "\n";
        
        for (size_t t = 0; t < max_len; ++t) {
            std::cout << std::setw(4) << t << " | "
                      << std::setw(2) << s1.state_history[t] << std::setw(3) << s2.state_history[t] << std::setw(3) << s3.state_history[t] << std::setw(3) << s4.state_history[t] << " | "
                      << std::setw(2) << bundles[0].threads[0].state_history[t] << std::setw(3) << bundles[0].threads[1].state_history[t] << std::setw(3) << bundles[0].threads[2].state_history[t] << " | "
                      << std::setw(2) << bundles[1].threads[0].state_history[t] << std::setw(3) << bundles[1].threads[1].state_history[t] << std::setw(3) << bundles[1].threads[2].state_history[t] << " | "
                      << std::setw(2) << bundles[2].threads[0].state_history[t] << std::setw(3) << bundles[2].threads[1].state_history[t] << std::setw(3) << bundles[2].threads[2].state_history[t] << " | "
                      << std::setw(2) << bundles[3].threads[0].state_history[t] << std::setw(3) << bundles[3].threads[1].state_history[t] << std::setw(3) << bundles[3].threads[2].state_history[t] << "\n";
        }
    }
};

// ============================================================================
// Main Simulation
// ============================================================================

int main() {
    std::cout << "\n" << std::string(100, '=') << "\n";
    std::cout << "System 5 Hierarchical Deterministic State Transition Simulation\n";
    std::cout << "Modeling Nested Concurrency with CogTaskFlow Subflows\n";
    std::cout << std::string(100, '=') << "\n";
    
    // Create System 5 state machine
    System5StateMachine system5;
    
    // Create taskflow executor
    tf::Executor executor;
    
    std::cout << "Running simulation for " << SIMULATION_STEPS << " time steps...\n\n";
    
    // Run simulation
    for (int t = 0; t < SIMULATION_STEPS; ++t) {
        tf::Taskflow taskflow;
        system5.step(taskflow);
        executor.run(taskflow).wait();
        system5.print_current_state();
    }
    
    // Print final state history
    system5.print_state_history();
    
    std::cout << std::string(100, '=') << "\n";
    std::cout << "Simulation Complete\n";
    std::cout << std::string(100, '=') << "\n\n";
    
    return 0;
}
