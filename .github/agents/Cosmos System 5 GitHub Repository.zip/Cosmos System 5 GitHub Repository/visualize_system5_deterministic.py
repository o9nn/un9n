#!/usr/bin/env python3
"""
System 5 Deterministic State Transition Visualization
Generates visual representations of the deterministic state sequences
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from matplotlib.colors import ListedColormap

def plot_deterministic_schedule():
    """Plot the deterministic state sequences as a timeline"""
    
    SIMULATION_STEPS = 60
    
    # Extract data from the simulation output
    # U1, U2, U3 states are strings: U-P, U-S, U-T
    # P1, P2, P3, P4 states are integers: 0, 1, 2, 3
    
    # Since we cannot read the output directly, we will hardcode the logic
    # and re-run the simulation logic in Python to get the state history.
    
    U_STATES = ["U-P", "U-S", "U-T"]
    P_NUM_STATES = 4
    
    u_history = [[], [], []]
    p_history = [[], [], [], []]
    
    p_current_states = [0, 0, 0, 0]
    
    for t in range(SIMULATION_STEPS + 1):
        # Universal Transitions
        u_index = t % 3
        u_history[0].append(U_STATES[t % 3])
        u_history[1].append(U_STATES[t % 3])
        u_history[2].append(U_STATES[t % 3])
        
        # Particular Transitions
        p_next_states = list(p_current_states)
        
        for i in range(4):
            # P1 at t % 5 == 0, P2 at t % 5 == 1, P3 at t % 5 == 2, P4 at t % 5 == 3
            if t % 5 == i:
                
                # Read current states of others
                sum_of_others = 0
                for j in range(4):
                    if i != j:
                        sum_of_others += p_current_states[j]
                
                # Revised Transition Function: S_i(t+1) = (S_i(t) + sum(S_j(t)) + U_idx(t)) mod 4
                next_state = (p_current_states[i] + sum_of_others + u_index) % P_NUM_STATES
                p_next_states[i] = next_state
            
            p_history[i].append(p_current_states[i])
            
        p_current_states = p_next_states
        
    # Combine all histories
    all_sequences = u_history + p_history
    set_names = ["U1", "U2", "U3", "P1", "P2", "P3", "P4"]
    
    # Map all unique states to colors
    # Convert all states to strings for sorting and plotting
    all_states_str = [str(state) for seq in all_sequences for state in seq]
    unique_states = sorted(list(set(all_states_str)))
    num_states = len(unique_states)
    
    # Create a colormap
    cmap = plt.cm.get_cmap('tab20', num_states)
    state_to_color = {state: cmap(i) for i, state in enumerate(unique_states)}
    
    fig, ax = plt.subplots(figsize=(18, 10))
    
    # Plot each set's sequence
    for i, (set_name, seq) in enumerate(zip(set_names, all_sequences)):
        y_pos = len(set_names) - i - 1
        
        for t in range(SIMULATION_STEPS + 1):
            state = str(seq[t]) # Convert to string for lookup and display
            color = state_to_color[state]
            
            rect = mpatches.Rectangle((t - 0.5, y_pos - 0.4), 1.0, 0.8,
                                      facecolor=color, edgecolor='black', linewidth=0.5)
            ax.add_patch(rect)
            
            # Add state label
            ax.text(t, y_pos, state, ha='center', va='center', fontsize=8, color='black', fontweight='bold')
    
    # Formatting
    ax.set_xlim(-1, SIMULATION_STEPS + 1)
    ax.set_ylim(-1, len(set_names))
    ax.set_yticks(range(len(set_names)))
    ax.set_yticklabels(set_names[::-1], fontsize=12, fontweight='bold')
    ax.set_xticks(range(SIMULATION_STEPS + 1))
    ax.set_xlabel('Time Step (t)', fontsize=14, fontweight='bold')
    ax.set_title('System 5 Deterministic State Transition Timeline (60 Steps)', 
                 fontsize=16, fontweight='bold', pad=20)
    ax.grid(True, axis='x', alpha=0.3)
    
    # Add cycle markers (Universal 3, Particular 5)
    for t in range(SIMULATION_STEPS + 1):
        if t % 3 == 0 and t != 0:
            ax.axvline(x=t - 0.5, color='blue', linestyle=':', linewidth=1, alpha=0.5)
        if t % 5 == 0 and t != 0:
            ax.axvline(x=t - 0.5, color='red', linestyle='--', linewidth=1, alpha=0.7)
    
    # Create a legend for the states
    legend_patches = [mpatches.Patch(color=state_to_color[state], label=str(state)) for state in unique_states]
    ax.legend(handles=legend_patches, title="States", bbox_to_anchor=(1.05, 1), loc='upper left', ncol=1)
    
    plt.tight_layout(rect=[0, 0, 0.85, 1]) # Adjust layout to make room for legend
    plt.savefig('/home/ubuntu/system5_deterministic_timeline.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: system5_deterministic_timeline.png")
    plt.close()

def main():
    print("\n" + "="*80)
    print("System 5 Deterministic State Transition Visualization")
    print("="*80 + "\n")
    
    print("Generating visualizations...\n")
    
    plot_deterministic_schedule()
    
    print("\n" + "="*80)
    print("All visualizations generated successfully!")
    print("="*80 + "\n")

if __name__ == "__main__":
    main()
